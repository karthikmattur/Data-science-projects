# Employee_Performance_Analysis

The Data science project which is given here is an analysis of employee performance. The goal of the project is to find the performance rating of the employees depending on features of the data, Such as TotalWorkExperienceInYears, EmpDepartment, Gender, ExperienceYearsInCurrentRole etc.,
The Goal and Insights of the project as follows:

1.Department wise performances
2.Top 3 Important Factors effecting employee performance
3.A trained model which can predict the employee performance based on factors as inputs.
4.This will be used to hire employees
5.Recommendations to improve the employee performance based on insights from analysis
